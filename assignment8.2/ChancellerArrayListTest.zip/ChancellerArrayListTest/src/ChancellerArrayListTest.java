// Chanceller Waters
//Assignment 8.2: Array list test
//07-29-2026

import java.util.ArrayList;
import java.util.Scanner;

//code purpose and scope

//find and return largest value in ArrayList
// if list is empty; Return a 0
//displays array list of entered integers in ascending order and displays the largest one (max) separately

public class ChancellerArrayListTest {
    public static Integer max(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            return 0;
        }

        Integer maxVal = list.get(0);


        int i;
        for (i = 1; i < list.size();
        i++){
            if (list.get(i) > maxVal) {
                maxVal = list.get(i);
            }
        }
        return maxVal;
    }
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> inputList = new ArrayList<>();


        System.out.println("Please Enter Integers( enter a 0 to stop):");

        //Loop to keep reading integers until the user enters a 0
        while (true)  {
            if (scanner.hasNextInt()) {
                int number = scanner.nextInt();
                inputList.add(number);

                if (number == 0) {
                    break; //loop ends when 0 is entered
                }
            }else{
                System.out.println("input is invalid. please enter an integer.");
                scanner.next();
            }
        }

        Integer LargestValue = max(inputList);


        //Displays results to user
        System.out.println("\nYour Entered list: " + inputList);
        System.out.println("The Largest Value in your ArrayList is : " + LargestValue);

        scanner.close();

    }

        }
